/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stefanov.pangarov_kiril.adconsultasbd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Kiril_SP
 */
public class kirilVideojuegos {

    static final String DB_URI = "jdbc:mysql://localhost:3306/kiril";
    static final String USER = "kiril";
    static final String PASS = "12345";
    static final String QUERY = "select * from Videojuegos;";
    static final String QUERY2 = "insert into Videojuegos (id ,nombre, genero, fechaLanzamiento, compañia, precio) values (10 ,'Grand Theft Auto III', 'Sandbox', '2003-01-01', 'Rockstar', 45.34);";

    @SuppressWarnings("CallToPrintStackTrace")
    public static void main(String[] args) {

        try ( Connection conn = DriverManager.getConnection(DB_URI, USER, PASS);  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery(QUERY)) {

            //stmt.executeUpdate(QUERY2);

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println(", Nombre: " + rs.getString("nombre"));
                System.out.println(", Genero: " + rs.getString("genero"));
                System.out.println(", Fecha de Lanzamiento: " + rs.getDate("fechaLanzamiento"));
                System.out.println(", Compañia: " + rs.getString("compañia"));
                System.out.println("y Precio: " + rs.getFloat("precio"));

            }
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

}
